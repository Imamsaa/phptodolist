<?php
function showTodolist()
{
    global $todolist;
    echo "APLIKASI TODOLIST".PHP_EOL;
    foreach ($todolist as $number => $value) {
        echo "$number. $value".PHP_EOL;
    }
}