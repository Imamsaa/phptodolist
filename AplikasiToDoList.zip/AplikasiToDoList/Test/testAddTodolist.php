<?php
require_once "..\BussinesLogic\addTodolist.php";
require_once "..\Model\Todolist.php";

addTodolist("EKO");

var_dump($todolist);