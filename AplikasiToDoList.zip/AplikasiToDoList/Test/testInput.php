<?php
require_once "..\Helper\Input.php";

$name = Input("Name");
echo "Hello $name";