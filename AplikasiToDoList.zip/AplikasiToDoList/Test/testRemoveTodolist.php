<?php
require_once "..\Model\Todolist.php";
require_once '..\BussinesLogic\removeTodolist.php';
require_once '..\BussinesLogic\showTodolist.php';

$todolist[1] = "Imam";
$todolist[2] = "Imam";
$todolist[3] = "Imam";
$todolist[4] = "Halo";

showTodolist();

removeTodolist(1);

showTodolist();

var_dump(removeTodolist(4));
