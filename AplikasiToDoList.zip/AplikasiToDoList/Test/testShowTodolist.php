<?php

require_once "../BussinesLogic\showTodolist.php";
require_once "../Model\Todolist.php";

$todolist[1] = "Imam";
$todolist[2] = "Imam";
$todolist[3] = "Imam";
$todolist[4] = "Imam";
$todolist[5] = "Imam";
showTodolist();