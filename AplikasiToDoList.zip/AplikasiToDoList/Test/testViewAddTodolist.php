<?php

require_once '..\View\viewAddTodolist.php';
require_once '..\BussinesLogic\addTodolist.php';
require_once '..\BussinesLogic\showTodolist.php';
require_once '..\Helper\Input.php';
require_once "..\Model\Todolist.php";

addTodolist("EKO");
addTodolist("Kurniawan");
addTodolist("Kanedi");

viewAddTodolist();

showTodolist();

viewAddTodolist();

showTodolist();