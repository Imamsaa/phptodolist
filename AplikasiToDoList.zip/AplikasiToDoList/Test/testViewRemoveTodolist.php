<?php
require_once "..\Model\Todolist.php";
require_once '..\View\viewRemoveTodolist.php';
require_once '..\BussinesLogic\addTodolist.php';
require_once "..\BussinesLogic\showTodolist.php";

addTodolist("imam");
addTodolist("safii");

showTodolist();

viewRemoveTodolist();

showTodolist();