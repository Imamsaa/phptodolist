<?php
require_once '..\View\viewShowTodolist.php';
require_once "..\BussinesLogic\addTodolist.php";

addTodolist("Imam");
addTodolist("Safii");
addTodolist("Ganteng");

viewShowTodolist();