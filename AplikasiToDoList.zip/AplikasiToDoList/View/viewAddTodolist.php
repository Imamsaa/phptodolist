<?php
require_once __DIR__."\..\Helper\Input.php";
require_once __DIR__."\..\BussinesLogic\addTodolist.php";

function viewAddTodolist()
{
    echo "MENAMBAH TODO".PHP_EOL;

    $todo = input("Todo ( x untuk batal ) ");

    if ($todo == "x") {
        echo "Batal menambah Todo".PHP_EOL;
    }else{
        addTodolist($todo);
    }
}