<?php
require_once __DIR__."\..\Helper\Input.php";
require_once __DIR__.'\..\BussinesLogic\removeTodolist.php';

function viewRemoveTodolist()
{
    echo "MENGHAPUS TODO";

    $pilihan = input("Nomor (x untuk batal) ");


    if($pilihan == "x"){
        echo "Batal Menghapus Todo".PHP_EOL;
    }else{
        $success = removeTodolist($pilihan);
        if($success){
            echo "Berhasil Menghapus Todo No $pilihan".PHP_EOL;
        }else{
            echo "Batal Menghapus Todo No $pilihan".PHP_EOL;
        }
    }
}