<?php

require_once __DIR__."\..\BussinesLogic\showTodolist.php";
require_once __DIR__.'\..\View\viewAddTodolist.php';
require_once __DIR__.'\..\View\viewRemoveTodolist.php';
require_once __DIR__."\..\Model\Todolist.php";
require_once __DIR__."\..\Helper\Input.php";

function viewShowTodolist()
{
    while (True) {
        
        showTodolist();

    echo "MENU".PHP_EOL;
    echo "1. Tambah Todo".PHP_EOL;
    echo "2. Hapus Todo".PHP_EOL;
    echo "x. Keluar".PHP_EOL;

    $pilihan = input("Pilih");

    if ($pilihan == "1") {
        viewAddTodolist();
    }elseif ($pilihan == "2") {
        viewRemoveTodolist();
    }elseif ($pilihan == "x") {
        break;
    }else{
        echo "Pilihan tidak dimengerti".PHP_EOL;
    }
    }
    echo "Sampai Jumpa Lagi :)".PHP_EOL;
}