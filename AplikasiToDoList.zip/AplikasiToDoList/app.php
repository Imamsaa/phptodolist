<?php
require_once __DIR__."\Model/Todolist.php";
require_once __DIR__."\BussinesLogic/addTodolist.php";
require_once __DIR__."\BussinesLogic/removeTodolist.php";
require_once __DIR__."\BussinesLogic/showTodolist.php";
require_once __DIR__."\View/viewShowTodolist.php";
require_once __DIR__."\View/viewAddTodolist.php";
require_once __DIR__."\View/viewRemoveTodolist.php";
require_once __DIR__."\Helper/Input.php";

echo "Aplikasi To DO List".PHP_EOL;
viewShowTodolist();